package tictactoe;

public class MancheFactory {


    public Manche createManche() {
        return new Manche();
    }
}

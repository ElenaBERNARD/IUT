package tictactoe;

public class OccupiedCellException extends Exception {
}

package tictactoe;

public interface Joueur {
    void joue(Grille grille);

    void setOpponent(Joueur opponent);
}

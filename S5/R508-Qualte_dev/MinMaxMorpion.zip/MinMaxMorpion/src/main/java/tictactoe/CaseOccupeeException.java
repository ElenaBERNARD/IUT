package tictactoe;

public class CaseOccupeeException extends Exception {
}

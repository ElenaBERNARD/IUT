import { 
    getAllOrganisationsService, 
    createOrganisationService, 
    addTeamService, 
    removeTeamService, 
    getOrganisationByIdService 
} from "@/services/org.service";

export default {
    namespaced: true,
    state: {
        organisationSecret: '',
        organisationNames: [],
        currentOrganisation: null
    },
    mutations: {
        setOrganisationSecret(state, secret) {
            state.organisationSecret = secret;
        },
        setOrganisationNames(state, names) {
            state.organisationNames = names;
        },
        setCurrentOrganisation(state, org) {
            state.currentOrganisation = org;
        },
    },
    actions: {
        async getOrganisations({ commit }) {
            try {
                const result = await getAllOrganisationsService();
                if (result.error === 0) {
                    commit("setOrganisationNames", result.data);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans getOrganisations()", { root: true });
            }
        },

        async getOrganisation({ commit }, id) {
            try {
                const result = await getOrganisationByIdService(id);
                if (result.error === 0) {
                    commit("setCurrentOrganisation", result.data[0]);
                    return result.data[0];
                } else {
                    commit("setCurrentOrganisation", null);
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans getOrganisation()", { root: true });
            }
        },

        async addTeam({ commit }, idTeam) {
            try {
                const result = await addTeamService(idTeam);
                if (result.error === 0) {
                    commit("setCurrentOrganisation", result.data);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans addTeam()", { root: true });
            }
        },

        async removeTeam({ commit }, idTeam) {
            try {
                const result = await removeTeamService(idTeam);
                if (result.error === 0) {
                    commit("setCurrentOrganisation", result.data);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans removeTeam()", { root: true });
            }
        },

        async createOrganisation({ commit }, data) {
            try {
                const result = await createOrganisationService(data);
                if (result.error === 0) {
                    commit("setCurrentOrganisation", result.data);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans createOrganisation()", { root: true });
            }
        },
    }
};
import { getAllAliasesService, createHeroService, updateHeroService, getHeroByIdService, updateHeroNoSecretService } from '@/services/hero.service';

export default {
    namespaced: true,
    state: {
        heroAliases: [],
        currentHero: null,
    },
    getters: {
    },
    mutations: {
        setHeroAliases(state, aliases) {
            state.heroAliases = aliases
        },
        setCurrentHero(state, hero) {
            state.currentHero = hero
        },
    },
    actions: {
        async getHeroAliases({ commit }) {
            let result = null;
            try {
                result = await getAllAliasesService();
                if (result.error === 0) {
                    commit("setHeroAliases", result.data);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans getHeroAliases()", { root: true });
            }
        },
        
        async createHero({ commit }, hero) {
            let result = null;
            try {
                result = await createHeroService(hero);
                if (result.error === 0) {
                    commit("setCurrentHero", result.data);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans createHero()", { root: true });
            }
        },
        
        async updateHero({ commit }, data) {
            let result = null;
            try {
                result = await updateHeroService(data);
                if (result.error === 0) {
                    commit("setCurrentHero", result.data);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans updateHero()", { root: true });
            }
        },

        async updateHeroNoSecret({ commit }, data) {
            let result = null;
            try {
                result = await updateHeroNoSecretService(data);
                if (result.error === 0) {
                    commit("setCurrentHero", result.data);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans updateHero()", { root: true });
            }
        },
        
        async getHero({ commit }, data) {
            let result = null;
            try {
                result = await getHeroByIdService(data);
                if (result.error === 0) {
                    commit("setCurrentHero", result.data[0]);
                    return result.data[0];
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans getHero()", { root: true });
            }
            return result?.data?.[0];
        },        
    }
}
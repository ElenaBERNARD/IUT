import Vue from 'vue'
import Vuex from 'vuex'

import hero from './hero'
import team from './team'
import org from './org'
import auth from './auth'

Vue.use(Vuex)

export default new Vuex.Store({
    modules: {
        hero,
        team,
        org,
        auth
    },
    state: {
        isError: false,
        errorMessage: ''
    },
    mutations: {
        setError(state, message) {
            state.isError = true
            state.errorMessage = message
        },
        clearError(state) {
            state.isError = false
            state.errorMessage = ''
        }
    },
})
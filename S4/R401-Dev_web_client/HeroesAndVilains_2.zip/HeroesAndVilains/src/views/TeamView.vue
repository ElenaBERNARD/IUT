<template>
    <v-container fill-height>
        <v-row v-if="!currentTeam" class="fill-height d-flex flex-column justify-center align-center">
            <v-btn color="primary" @click="goBack">
                Connect to an organisation
            </v-btn>
            <v-alert type="error" class="mt-3" style="max-width: fit-content;" dense text>
                Please connect to an organisation to access teams
            </v-alert>
        </v-row>
        <v-row v-if="currentTeam">
            <v-col>
                <v-card>
                    <v-card-title>{{ currentTeam.name }}</v-card-title>
                </v-card>
            </v-col>

        </v-row>
        <v-row v-if="currentTeam" justify="center" class="mb-6">
            <v-btn color="primary" @click="openAddDialog">
                Add Hero
            </v-btn>
        </v-row>

        <v-row v-if="currentTeam && members.length" justify="center">
            <v-col v-for="member in members" :key="member._id" cols="12" md="6">
                <v-card class="pa-3">
                    <v-card-title>{{ member.publicName }}</v-card-title>
                    <v-card-subtitle v-if="member.realName">({{ member.realName }})</v-card-subtitle>
                    <v-divider></v-divider>
                    <v-card-text>
                        <p v-if="member.powers.length"><strong>Powers:</strong></p>
                        <v-list v-if="member.powers.length">
                            <v-list-item v-for="power in member.powers" :key="power.name">
                                <v-list-item-content>
                                    <v-list-item-title>
                                        {{ power.name }} ({{ powerTypes[power.type - 1] }}): Level {{ power.level }}
                                    </v-list-item-title>
                                </v-list-item-content>
                            </v-list-item>
                        </v-list>
                        <p v-else>No powers</p>
                    </v-card-text>
                    <v-card-actions>
                        <v-btn color="primary" @click="editHero(member._id)">
                            Edit
                        </v-btn>
                        <v-btn color="error" @click="openDeleteDialog(member)">
                            Remove
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
        </v-row>
        <ConfirmDialog ref="deleteHeroRef" />
        <AddHero ref="addHeroRef" />
    </v-container>
</template>

<script>
import ConfirmDialog from '@/components/ConfirmDialog.vue';
import AddHero from '@/components/AddHero.vue';
import { mapState, mapActions } from 'vuex';

export default {
    name: 'TeamView',

    data() {
        return {
            members: [],
            powerTypes: ["Force", "Vitesse", "Endurance", "Magie", "Effrayant", "Furtivité", "Stupidité"],
        };
    },

    components: {
        ConfirmDialog,
        AddHero,
    },

    computed: {
        ...mapState('team', ['currentTeam']),
    },

    methods: {
        ...mapActions('hero', ['getHero', 'addHero']),
        ...mapActions('team', ['teamRemoveHeroes']),


        /*
        * Recupere les informations de chaque membre de l'equipe
        * Stocke les informations dans members
        */
        async fetchTeamMembers() {
            if (!this.currentTeam || !this.currentTeam.members) return;

            const members = [];
            for (const memberId of this.currentTeam.members) {
                const hero = await this.getHero({ id: memberId });
                if (hero) {
                    members.push(hero);
                }
            }
            this.members = members;
        },

        /*
        * Fonction appelee par le bouton "Edit" d'un hero
        * Redirige l'utilisateur vers la page d'edition du hero
        * Utilise getHero pour recuperer les informations du hero dans le store
        */
        async editHero(heroId) {
            if (!heroId) {
                this.$toast.error('Invalid team ID');
                return;
            }
            let hero = await this.getHero({ id: heroId });
            if (!hero) {
                this.$toast.error('Team not found');
                return;
            }
            this.$router.push(`/hero`);
        },

        /*
        * Fonction appelee par le bouton "Add Hero"
        * Ouvre la fenetre de creation d'un hero
        * CF components/AddHero.vue
        */
        openAddDialog() {
            this.$refs.addHeroRef.openDialog(() => {
                this.fetchTeamMembers();
            }, this.currentTeam.members
            );
        },

        /*
        * Fonction appelee par le bouton "Remove" d'un hero
        * Ouvre la fenetre de confirmation de suppression d'un hero
        * CF components/ConfirmDialog.vue
        */
        openDeleteDialog(hero) {
            this.$refs.deleteHeroRef.openDialog(
                () => { this.teamRemoveHeroes({ idHeroes: [hero._id], idTeam: this.currentTeam._id }); },
                "Remove Hero",
                `Are you sure you want to remove ${hero.publicName} from the team ?`
            );
        },

        /*
        * Retourne a la page des organisations
        */
        goBack() {
            this.$router.push('/organisations');
        },
    },

    // Recupere les membres de l'equipe lors du changement de l'equipe courante
    watch: {
        currentTeam() {
            this.fetchTeamMembers();
        },
    },

    // Recupere les membres de l'equipe lors du chargement de la page
    mounted() {
        if (this.currentTeam) {
            this.fetchTeamMembers();
        }
    },
};
</script>
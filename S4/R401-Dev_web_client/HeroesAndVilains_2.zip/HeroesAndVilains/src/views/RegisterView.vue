<template>
    <v-container>
        <v-card class="pa-5">
            <v-card-title>Inscription</v-card-title>
            <v-card-text>
                <v-text-field v-model="login" label="Nom d'utilisateur" required></v-text-field>
                <v-text-field v-model="password" label="Mot de passe" type="password" required></v-text-field>
                <v-text-field v-model="hero" label="Nom du héros" required></v-text-field>
                <VueRecaptcha 
                    sitekey="6LdzWJkkAAAAAOG1QjA_LmULztIgSqmGokocysOx" 
                    :loadRecaptchaScript="true"
                    ref="recaptcha" 
                    @verify="onCaptchaVerify" 
                    @expired="onCaptchaExpired" />
            </v-card-text>
            <v-card-actions>
                <v-btn color="primary" @click="doRegister">S'inscrire</v-btn>
            </v-card-actions>
        </v-card>
    </v-container>
</template>

<script>
import VueRecaptcha from 'vue-recaptcha';

import { mapActions } from 'vuex';

export default {
    name: 'RegisterView',

    components: { 
        VueRecaptcha,
    },

    data() {
        return {
            login: '',
            password: '',
            hero: '',
            captchaToken: null,
            isSubmitting: false,
        };
    },
    methods: {
        ...mapActions('auth', ['register']),
        async doRegister() {
            if (!this.captchaToken) {
                alert("Veuillez compléter le captcha");
                return;
            }

            if (this.isSubmitting) {
                return;
            }

            this.isSubmitting = true;

            try {
                let answer = await this.register({
                    login: this.login,
                    password: this.password,
                    hero: this.hero,
                    captchaToken: this.captchaToken
                });
                if(answer) {
                    this.$router.replace('/profile');
                } else {
                    this.resetRecaptcha();
                }
            } catch (error) {
                alert("Erreur : " + error.message);
            } finally {
                this.isSubmitting = false;
            }
        },
        onCaptchaVerify(response) {
            console.log('Verify: ' + response);
            this.captchaToken = response;
        },
        onCaptchaExpired() {
            console.log('Captcha expired');
            this.captchaToken = null;
        },
        resetRecaptcha() {
            this.$refs.recaptcha.reset(); 
        },
    }
};
</script>

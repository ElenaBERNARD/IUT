package org.capacitor.quasar.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

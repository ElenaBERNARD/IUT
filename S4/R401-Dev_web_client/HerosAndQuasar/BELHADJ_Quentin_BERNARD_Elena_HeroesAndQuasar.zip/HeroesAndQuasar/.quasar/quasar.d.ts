/* eslint-disable */
/// <reference types="@quasar/app-webpack" />

/// <reference types="vite/client" />

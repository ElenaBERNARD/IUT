<template>
    <v-container>
        <v-card class="pa-4">
            <v-card-title>Connexion</v-card-title>
            <v-card-text>
                <v-text-field v-model="identifiant" label="Identifiant" required></v-text-field>
                <v-text-field v-model="password" label="Mot de passe" type="password" required></v-text-field>
            </v-card-text>
            <v-card-actions>
                <v-btn color="primary" @click="authenticate">Se connecter</v-btn>
            </v-card-actions>
            <v-alert v-if="error" type="error">{{ error }}</v-alert>
        </v-card>
    </v-container>
</template>

<script>
import { mapActions } from 'vuex';

export default {
    data() {
        return {
            identifiant: '',
            password: '',
            error: ''
        };
    },
    methods: {
        ...mapActions('auth', ['login', 'getUser']),
        async authenticate() {
            const result = await this.login({login: this.identifiant, password: this.password});
            if (result) {
                this.getUser();
                this.$router.replace('/profile');
            } else {
                this.error = 'Identifiant ou mot de passe incorrect';
            }
        }
    }
};
</script>
<template>
    <v-dialog v-model="isError" max-width="500px" persistent>
        <v-card>
            <v-card-title>Error</v-card-title>
            <v-alert type="error" dense text>
                {{ errorMessage }}
            </v-alert>
            <v-card-actions>
                <v-btn @click="closeErrorDialog">Close</v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script>
import { mapState, mapMutations } from 'vuex';

export default {
    name: 'ErrorDialog',
    computed: {
        ...mapState(['isError', 'errorMessage']),
    },
    methods: {
        ...mapMutations(['clearError']),
        closeErrorDialog() {
            this.clearError();
        },
    },
};

</script>
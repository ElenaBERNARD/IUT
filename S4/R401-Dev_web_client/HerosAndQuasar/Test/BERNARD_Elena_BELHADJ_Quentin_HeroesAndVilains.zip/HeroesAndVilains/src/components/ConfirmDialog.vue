<template>
    <v-dialog v-model="dialog" max-width="500px">
        <v-card>
            <v-card-title>{{ title }}</v-card-title>
            <v-card-text>
                {{ message }}
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn color="blue darken-1" text @click="closeDialog">Cancel</v-btn>
                <v-btn color="primary" text @click="confirm">Confirm</v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script>

export default {
    name: 'ConfirmDialog',
    data() {
        return {
            dialog: false,
            title: "",
            message: "",
            onConfirm: Function,
        }
    },
    methods: {
        closeDialog() {
            this.dialog = false;
        },
        openDialog(onConfirm, title = "Confirm", message = "Are you sure you want to do this ? This action may be definitive.") {
            this.onConfirm = onConfirm;
            this.dialog = true;
            this.title = title;
            this.message = message;
        },
        confirm() {
            this.onConfirm();
            this.closeDialog();
        },
    },
};
</script>
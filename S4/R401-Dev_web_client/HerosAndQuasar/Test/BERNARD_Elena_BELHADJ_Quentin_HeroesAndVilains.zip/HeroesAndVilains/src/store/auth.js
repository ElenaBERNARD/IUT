import { loginUserService, getUserInfoService, registerUserService } from '@/services/auth.service';

export default {
    namespaced: true,
    state: {
        currentUser: null,
        currentPassword: null,
    },
    mutations: {
        setUser(state, user) {
            state.currentUser = user;
        },
        setPassword(state, password) {
            state.currentPassword = password;
        },
        setProfile(state, profile) {
            state.currentUser = profile.login
            state.currentPassword = profile.password
        }
    },
    actions: {
        async login({ commit }, info) {
            let result = null
            try {
                result = await loginUserService(info);
                if (result.error === 0) {
                    commit('setUser', result.data.name);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (error) {
                commit("setError", result.data.data, { root: true });
            }
        },
        async register({ commit }, userInfo) {
            let result = null
            try {
                result = await registerUserService(userInfo);
                if (result.error === 0) {
                    // Ici j'ai retirer les commit pour forcer a passer par le login
                    // il parait que c'est plus secure
                    // commit('setUser', result.data.login);
                    // commit('setPassword', result.data.password);
                    return result.data;
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (error) {
                commit("setError", result.data.data, { root: true });
            }
        },
        logout({ commit }) {
            commit('setUser', null);
            commit('setPassword', null);
            commit('hero/setCurrentHero', null, { root: true });
        },
        async getUser({ commit, state }) {
            let result = null
            try {
                result = await getUserInfoService(state.currentUser)

                if (result.error === 0) {
                    commit('setProfile', result.data)
                    // Pour mettre le hero directement dans le store hero
                    // Je c'est pas si c'est une bonne idée de faire comme ca TBH
                    commit('hero/setCurrentHero', result.data.hero, { root: true });
                    return result.data
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (error) {
                commit("setError", result.data.data, { root: true });
            }
        },
    }
};

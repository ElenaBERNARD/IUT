import { 
    getAllTeamsService, 
    createTeamService, 
    teamAddHeroesService, 
    teamRemoveHeroesService 
} from '@/services/team.service';

export default {
    namespaced: true,
    state: {
        teams: [],
        currentTeam: null,
    },
    mutations: {
        setTeams(state, teams) {
            state.teams = teams;
        },
        setCurrentTeam(state, team) {
            state.currentTeam = team;
        },
    },
    actions: {
        async getTeams({ commit }) {
            try {
                const result = await getAllTeamsService();
                if (result.error === 0) {
                    commit("setTeams", result.data);
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans getTeams()", { root: true });
            }
        },

        async createTeam({ commit }, name) {
            try {
                const result = await createTeamService(name);
                if (result.error === 0) {
                    commit("setCurrentTeam", result.data);
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans createTeam()", { root: true });
            }
        },

        async teamAddHeroes({ commit }, data) {
            try {
                const result = await teamAddHeroesService(data);
                if (result.error === 0) {
                    commit("setCurrentTeam", result.data);
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans teamAddHeroes()", { root: true });
            }
        },

        async teamRemoveHeroes({ commit }, data) {
            try {
                const result = await teamRemoveHeroesService(data);
                if (result.error === 0) {
                    commit("setCurrentTeam", result.data);
                } else {
                    commit("setError", result.data.data, { root: true });
                }
            } catch (err) {
                commit("setError", "Cas anormal dans teamRemoveHeroes()", { root: true });
            }
        }
    }
};
<template>
    <v-container>
        <v-card v-if="!currentUser" class="pa-5 text-center">
            <v-card-title>Vous n'êtes pas connecté</v-card-title>
            <v-card-text>
                <p>
                    Vous avez déjà un compte ?
                    <router-link to="/login">Connectez-vous</router-link>
                </p>
                <p>
                    Sinon, <router-link to="/register">inscrivez-vous</router-link> !
                </p>
            </v-card-text>
        </v-card>

        <v-card v-else>
            <v-card-title>
                {{ currentUser }}
            </v-card-title>
            <v-card-text>
                {{ currentPassword }}
            </v-card-text>
        </v-card>

        <v-row v-if="currentUser && currentHero">
            <v-col>
                <v-card class="pa-3">
                    <v-card-title>{{ currentHero.publicName }}</v-card-title>
                    <v-card-subtitle v-if="currentHero.realName">({{ currentHero.realName }})</v-card-subtitle>
                    <v-divider></v-divider>
                    <v-card-text>
                        <p v-if="currentHero.powers.length"><strong>Pouvoirs:</strong></p>
                        <v-list v-if="currentHero.powers.length">
                            <v-list-item v-for="power in currentHero.powers" :key="power.name">
                                <v-list-item-content>
                                    <v-list-item-title>
                                        {{ power.name }} ({{ powerTypes[power.type - 1] }}): Niveau {{ power.level }}
                                    </v-list-item-title>
                                </v-list-item-content>
                            </v-list-item>
                        </v-list>
                        <p v-else>Aucun pouvoir</p>
                    </v-card-text>
                    <v-card-actions>
                        <v-btn color="primary" @click="editHero(currentHero._id)">
                            Edit
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
        </v-row>
        <EditHeroDialog ref="editHeroRef" />
    </v-container>
</template>

<script>
import EditHeroDialog from '@/components/EditHeroDialog.vue';

import { mapActions, mapState } from 'vuex'

export default {
    name: 'ProfileView',

    components: {
        EditHeroDialog,
    },

    data() {
        return {
            powerTypes: ["Force", "Vitesse", "Endurance", "Magie", "Effrayant", "Furtivité", "Stupidité"],
        }
    },

    computed: {
        ...mapState('auth', ['currentUser', 'currentPassword']),
        ...mapState('hero', ['currentHero']),
    },

    methods: {
        ...mapActions('hero', ['updateHeroNoSecret']),
        /*
        * Fonction appelee par le bouton "Edit"
        * Ouvre la boite de dialogue pour editer un hero
        * CF components/EditHeroDialog.vue
        */
        editHero() {
            this.$refs.editHeroRef.openDialog(
                (hero) => {
                    this.updateHeroNoSecret({ hero: hero });
                }
            );
        },
    }
}
</script>

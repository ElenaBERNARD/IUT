<template>
    <v-dialog v-model="dialog" max-width="600px">
        <v-card>
            <v-card-title>Update hero</v-card-title>
            <v-card-text>
                <v-text-field label="Display Name" v-model="newHero.publicName"></v-text-field>
                <v-text-field label="Real Name" v-model="newHero.realName"></v-text-field>

                <v-container>
                    <v-row v-for="(power, index) in newHero.powers" :key="index">
                        <v-col cols="5">
                            <v-text-field label="Power Name" v-model="power.name"></v-text-field>
                        </v-col>
                        <v-col cols="4">
                            <v-select label="Type" v-model="power.type"
                                :items="powerTypes.map((type, i) => ({ text: type, value: i + 1 }))" item-text="text"
                                item-value="value"></v-select>
                        </v-col>
                        <v-col cols="3">
                            <v-btn color="red" @click="removePower(index)">x</v-btn>
                        </v-col>
                    </v-row>
                </v-container>

                <v-btn color="green" @click="addPower">+ Add Power</v-btn>

            </v-card-text>
            <v-card-actions>
                <v-btn color="grey" @click="closeDialog">Cancel</v-btn>
                <v-btn color="primary" @click="startConfirmation" :disabled="areIdentical">Update Hero</v-btn>
            </v-card-actions>
        </v-card>
        <ConfirmDialog ref="confirmUpdateRef" />
    </v-dialog>
</template>

<script>
import ConfirmDialog from '@/components/ConfirmDialog.vue';

import { mapState } from 'vuex';

export default {
    name: 'AddHero',

    components: {
        ConfirmDialog,
    },
    data() {
        return {
            dialog: false,
            tab: null,
            selectedHeroes: [],
            powerTypes: ["Force", "Vitesse", "Endurance", "Magie", "Effrayant", "Furtivité", "Stupidité"],
            newHero: {
                publicName: '',
                realName: '',
                powers: [],
            },
            members: [],
            onConfirm: Function,
        };
    },
    computed: {
        ...mapState('hero', ['currentHero']),
        areIdentical() {
            return JSON.stringify(this.currentHero) === JSON.stringify(this.newHero);
        },
    },
    methods: {
        openDialog(onConfirm) {
            this.onConfirm = onConfirm;
            // Reset on open
            this.dialog = true;
            this.newHero = {
                _id: this.currentHero._id,
                publicName: this.currentHero.publicName,
                realName: this.currentHero.realName,
                powers: this.currentHero.powers.map(power => ({ ...power })), // Shallow clone each power
            };
        },

        closeDialog() {
            this.dialog = false;
        },
        startConfirmation() {
            this.$refs.confirmUpdateRef.openDialog(
                this.confirm,
                "Update Hero",
                "Are you sure you want to update this hero ?");
        },
        confirm() {
            this.onConfirm(this.newHero);
            this.closeDialog();
        },
        addPower() {
            this.newHero.powers.push({ name: 'newPower', type: 0, level: 1 });
        },
        removePower(index) {
            this.newHero.powers.splice(index, 1);
        },
    }
}
</script>
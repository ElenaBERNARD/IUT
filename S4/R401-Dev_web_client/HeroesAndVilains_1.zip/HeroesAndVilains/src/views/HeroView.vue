<template>
    <v-container fill-height>
        <v-row v-if="!currentHero" class="fill-height d-flex flex-column justify-center align-center">
            <v-btn color="primary" @click="goBack">
                Connect to an organisation
            </v-btn>
            <v-alert type="error" class="mt-3" style="max-width: fit-content;" dense text>
                Please connect to an organisation to access heroes
            </v-alert>
        </v-row>
        <v-row v-if="currentHero">
            <v-col>
                <v-card class="pa-3">
                    <v-card-title>{{ currentHero.publicName }}</v-card-title>
                    <v-card-subtitle v-if="currentHero.realName">({{ currentHero.realName }})</v-card-subtitle>
                    <v-divider></v-divider>
                    <v-card-text>
                        <p v-if="currentHero.powers.length"><strong>Powers:</strong></p>
                        <v-list v-if="currentHero.powers.length">
                            <v-list-item v-for="power in currentHero.powers" :key="power.name">
                                <v-list-item-content>
                                    <v-list-item-title>
                                        {{ power.name }} ({{ powerTypes[power.type - 1] }}): Level {{ power.level }}
                                    </v-list-item-title>
                                </v-list-item-content>
                            </v-list-item>
                        </v-list>
                        <p v-else>No powers</p>
                    </v-card-text>
                    <v-card-actions>
                        <v-btn color="primary" @click="editHero(currentHero._id)">
                            Edit
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
        </v-row>
        <EditHeroDialog ref="editHeroRef" />

    </v-container>
</template>

<script>
import EditHeroDialog from '@/components/EditHeroDialog.vue';

import { mapState, mapActions } from 'vuex';

export default {
    name: 'HeroView',

    components: {
        EditHeroDialog,
    },

    data() {
        return {
            powerTypes: ["Force", "Vitesse", "Endurance", "Magie", "Effrayant", "Furtivité", "Stupidité"],
        };
    },

    computed: {
        ...mapState('hero', ['currentHero']),
        ...mapState('org', ['organisationSecret']),
    },

    methods: {
        ...mapActions('hero', ['updateHero']),
        /*
        * Fonction appelee par le bouton "Edit"
        * Ouvre la boite de dialogue pour editer un hero
        * CF components/EditHeroDialog.vue
        */
        editHero() {
            this.$refs.editHeroRef.openDialog(
                (hero) => {
                    this.updateHero({ hero: hero, secret: this.organisationSecret });
                }
            );
        },
        /*
        * Retourne a la page des organisations
        */
        goBack() {
            this.$router.push('/organisations');
        },
    },
};

</script>
<template>
    <v-container>
        <v-row class="mb-6" justify="center">
            <v-col cols="auto">
                <v-btn color="primary" @click="openCreateTeamDialog">
                    Create Team
                </v-btn>
            </v-col>
        </v-row>

        <v-row>
            <v-col v-for="team in teams" :key="team._id" cols="12" md="4">
                <v-card class="pa-3">
                    <v-card-title>{{ team.name }}</v-card-title>

                    <v-alert v-if="errorTeamId === team._id" type="error" dense text>
                        {{ errorMessage }}
                    </v-alert>
                </v-card>
            </v-col>
        </v-row>
        <CreateTeamDialog ref="createTeamRef" />
    </v-container>
</template>

<script>
import { mapState, mapActions, mapMutations } from 'vuex';
import CreateTeamDialog from '@/components/CreateTeamDialog.vue';

export default {
    name: 'TeamsView',

    components: {
        CreateTeamDialog,
    },

    data() {
        return {
            errorTeamId: null,
            errorMessage: "",
        };
    },

    computed: {
        ...mapState('team', ['teams']),
    },

    methods: {
        ...mapActions('team', ['getTeams', 'createTeam']),
        ...mapMutations('team', ['setCurrentTeam']),

        /*
         * Fonction appelee par le bouton "Create Team"
         * Ouvre la boite pour creer une nouvelle equipe
         * CF components/CreateTeamDialog.vue
         */
        async openCreateTeamDialog() {
            this.$refs.createTeamRef.openDialog(
                (name) =>{
                    this.handleTeamCreation(name);
                }
            );
        },

        /*
         * Fonction appelee par la boite de dialogue de creation d'equipe
         * Appelle l'action de creation d'equipe
         * Permet de rafraichir la liste des equipes apres la creation
         */
        async handleTeamCreation(name) {
            const data = {
                name: name,
            };
            await this.createTeam(data);
            this.getTeams();
        },
    },

    // Recupere les equipes au chargement de la page
    mounted() {
        this.getTeams();
    },
};
</script>

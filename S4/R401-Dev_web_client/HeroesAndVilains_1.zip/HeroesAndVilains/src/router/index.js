import Vue from 'vue'
import VueRouter from 'vue-router'
import HeroView from '@/views/HeroView.vue'
import OranisationView from '@/views/OrganisationsView.vue'
import OrganisationView from '@/views/OrganisationView.vue'
import TeamsView from '@/views/TeamsView.vue'
import TeamView from '@/views/TeamView.vue'
import OrganisationsView from '@/views/OrganisationsView.vue'


Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: OrganisationsView
  },
  {
    path: '/hero',
    name: 'hero',
    component: HeroView
  },
  {
    path: '/teams',
    name: 'teams',
    component: TeamsView
  },
  {
    path: '/team',
    name: 'team',
    component: TeamView
  },
  {
    path: '/organisations',
    name: 'organisations',
    component: OranisationView
  },
  {
    path: '/organisation',
    name: 'organisation',
    component: OrganisationView
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router

//
//  Crypto.swift
//  CryptoApp
//
//  Created by bernard adrien on 21/01/2025.
//

import Foundation

struct Crypto {
    var name: String
    var imageName: String
    var price: Double
}

//
//  CryptoAppApp.swift
//  CryptoApp
//
//  Created by bernard adrien on 14/01/2025.
//

import SwiftUI

@main
struct CryptoAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

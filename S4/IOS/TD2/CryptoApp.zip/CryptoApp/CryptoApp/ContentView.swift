//
//  ContentView.swift
//  WeatherApp
//
//  Created by bernard adrien on 14/01/2025.
//

import SwiftUI

struct ContentView: View {
    @State private var isEuro: Bool = false
    
    @State private var cryptos: [Crypto] = [
        Crypto(name: "MON", imageName: "bitcoin", price: 51),
        Crypto(name: "TUE", imageName: "ethereum", price: 21),
        Crypto(name: "WED", imageName: "ripple", price: 6),
        Crypto(name: "THU", imageName: "stellar", price: 11),
    ]
    var body: some View {
        
        ZStack {
            Color.black
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            VStack {
                VStack(spacing:30) {
                    HStack {
                        Text("Crypto App")
                            .font(.largeTitle).bold()
                            .foregroundStyle(.green)
                        
                        Button {
                            reloadPrices()
                        } label: {
                            Image(systemName: "arrow.clockwise.circle")
                                .foregroundColor(.green)
                                .font(.largeTitle)
                        }
                    }
                    HStack(spacing:30) {
                        
                        Image(systemName: "calendar.circle.fill")
                            .foregroundColor(.green)
                            .font(.largeTitle)
                        
                        Text("Tuesday January 21, 2025")
                            .foregroundStyle(.white)
                    }
                }
                
                Spacer()
                
                HStack(spacing:20) {
                    CryptoView(crypto: cryptos[0], isEuro: isEuro)
                    CryptoView(crypto: cryptos[1], isEuro: isEuro)
                    CryptoView(crypto: cryptos[2], isEuro: isEuro)
                    CryptoView(crypto: cryptos[3], isEuro: isEuro)
                }
                
                Spacer()
                
                Button {
                    convertPrices()
                } label: {
                    Text("Convert To \(isEuro ? "€" : "$")")
                        .frame(width: 280, height: 50)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .font(.title2).bold()
                        .cornerRadius(12)
                }
                Spacer()
            }
        }
    }
    func reloadPrices() {
        for i in 0..<cryptos.count {
            cryptos[i].price += 1
        }
    }
    func convertPrices() {
        isEuro.toggle()
    }
}

struct CryptoView: View {
    var crypto: Crypto
    var isEuro: Bool
    
    var body: some View {
        VStack {
            Text(crypto.name)
                .font(.title2)
                .foregroundStyle(.white)
            Image(crypto.imageName)
                .renderingMode(.original)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 40, height: 40)
            Text((isEuro ? "$ \(Int(crypto.price))k" : "\(Int(round(crypto.price*1.03)))k€"))
                .font(.title2).bold()
                .foregroundStyle(.white)
        }
    }
}

#Preview {
    ContentView()
}

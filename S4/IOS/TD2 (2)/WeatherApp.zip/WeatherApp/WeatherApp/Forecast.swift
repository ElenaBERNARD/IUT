//
//  Forecast.swift
//  WeatherApp
//
//  Created by bernard elena on 21/01/2025.
//

import Foundation

struct Forecast {
    var dayOfWeek: String
    var imageName: String
    var temperature: Int
}

//
//  ContentView.swift
//  WeatherApp
//
//  Created by bernard adrien on 14/01/2025.
//

import SwiftUI

struct ContentView: View {
    
    @State private var isNight: Bool = false
    
    @State private var forecasts: [Forecast] = [
        Forecast(dayOfWeek: "MON", imageName: "cloud.rain.fill", temperature: 14),
        Forecast(dayOfWeek: "TUE", imageName: "cloud.rain.fill", temperature: 11),
        Forecast(dayOfWeek: "WED", imageName: "cloud.fill", temperature: 16),
        Forecast(dayOfWeek: "THU", imageName: "cloud.sun.fill", temperature: 18),
        Forecast(dayOfWeek: "FRI", imageName: "cloud.fill", temperature: 15)
    ]
    
    var body: some View {
        
        ZStack {
            BackGroundView(topColor: isNight ? .black : .gray, bottomColor: isNight ? .gray : .white)
            
            VStack {
                HStack {
                    Text("Thury-Harcourt, Fr")
                        .font(.largeTitle).bold()
                        .foregroundStyle(.white)
                    Button {
                        reloadTemperature()
                    } label: {
                        Image(systemName: "arrow.clockwise.circle")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                    }
                }
                
                Image(systemName: isNight ? "cloud.moon.rain.fill" : "cloud.rain.fill")
                    .renderingMode(.original)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 180, height: 180)
                Text("17°")
                    .font(.system(size:70, weight: .medium))
                    .foregroundStyle(.white)
                    .padding(.bottom, 40)
                
                HStack(spacing:20) {
                    WeatherDayView(forecast: forecasts[0])
                    WeatherDayView(forecast: forecasts[1])
                    WeatherDayView(forecast: forecasts[2])
                    WeatherDayView(forecast: forecasts[3])
                    WeatherDayView(forecast: forecasts[4])
                }
                
                Spacer()
                
                Button {
                    // Action a realiser au click
                    isNight.toggle()
                } label: {
                    Text("Change Day Time")
                        .frame(width: 280, height: 50)
                        .background(Color.white)
                        .font(.title2).bold()
                        .cornerRadius(12)
                }
                
                Spacer()
            }
        }
    }
    
    func reloadTemperature() {
        for i in 0..<forecasts.count {
            forecasts[i].temperature += 1
        }
    }
}

struct WeatherDayView: View {
    var forecast: Forecast
    
    var body: some View {
        VStack {
            Text(forecast.dayOfWeek)
                .font(.title2)
                .foregroundStyle(.white)
            Image(systemName: forecast.imageName)
                .renderingMode(.original)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 40, height: 40)
            Text("\(forecast.temperature)°")
                .font(.title2).bold()
                .foregroundStyle(.white)
        }
    }
}

#Preview {
    ContentView()
}

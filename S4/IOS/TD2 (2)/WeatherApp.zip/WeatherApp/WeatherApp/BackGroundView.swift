//
//  BackGroundView.swift
//  WeatherApp
//
//  Created by bernard adrien on 21/01/2025.
//

import SwiftUI

struct BackGroundView: View {
    
    var topColor: Color
    var bottomColor: Color
    
    var body: some View {
        LinearGradient(colors: [topColor, bottomColor], startPoint: .topLeading, endPoint: .bottomTrailing)
            .edgesIgnoringSafeArea(.all)
    }
}

#Preview {
    BackGroundView(topColor: .white, bottomColor: .gray)
}

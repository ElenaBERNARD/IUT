//
//  BackGrondView.swift
//  WeatherApp
//
//  Created by bernard adrien on 21/01/2025.
//

import SwiftUI

struct BackGrondView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    BackGrondView()
}

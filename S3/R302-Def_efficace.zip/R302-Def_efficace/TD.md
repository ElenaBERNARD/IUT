# TD 1
## Les listes

Implementation de listes chainées

**Classe Cell representant un maillon de la chaine**
```
public class Cell {
    public int value;
    public Cell next;

    public Cell(int value){
        this.value = value;
        next = null;
    }
}
```

**Classe list contenant la première cellule de la chaine**
```

public class List {
    public Cell head;
    public int size;

    public class List(){
        head = null;
        size = 0;
    }
    . . .
}
```

**Fonction de recherche d'un element dans List**
```
public Cell find(int value){
    Cell c = head;
    while((c != null) && (c.value != value)){
        c = c.next;
    }
    return c;
}
```

**Fonction de recuperation d'un element dans List**
```
public Cell get(int index){
    Cell c = head;
    int i = 0;
    while((c != null) && (index != i)){
        c = c.next;
        i++;
    }
    return c;
}
```

**Fonction d'ajout d'un element dans List**
```
public Cell append(int value){
    Cell newCell = new Cell(value);
    if(size == 0){
        head = newCell;
    }
    else {
        Cell c = get(size - 1);
        c.next = newCell;
    }
    size++;
    return newCell;
}
```

**Fonction d'insertion d'un element dans List**
```
public Cell insert(int value, int index){
    Cell c = null;
    Cell newCell = new Cell(value);
    if(index > size) 
        index = size;
    if(size == 0)
        head = newCell;
    else if(index == 0){
        newCell.next = head;
        head = newCell;
    }
    else{
        c = get(index - 1);
        newCell.next = c.next;
        c.next = newCell;
    }
    size++;
    return newCell;
}
```

**Fonction de remplacement d'un element dans List**
```
public Cell replace(int value, int index){
    if(index < 0 || index >= size)
        return null;
    Cell c = get(index);
    c.value = value;
    return c;
}
```
# TD 2

## Les collections

**Set :** ensemble d'objet non indidces sans doublons
**List :** ensemble d'objets indicés
**Map :** ensemble associatifs d'objets non indices, chaque objet etant associe a une cle. Une cle est unique, mais plusieurs cles peuvent être associee au meme objet. 
**Queue :** ensemble d'objets, non indicé avec un schéma d'acces FIFO/LIFO

En Java les collections utilisent la généricité

En effet Set, List, Map, Queue sont des interfaces. Dans la plupart des cas on utilise une implémentation comme HashSet, ArrayList, HashMap, ArrayQueue

```
// Faux car int n'est pas une classe !
// Set<int> set = new HashSet<int>();

// Correct
Set<Integer> set = new HashSet<>();
```

**Methodes communes :**
```
int size()
void clear()
boolean isEmpty()
```

#### HashSet

boolean add(E e) :  ajoute l'objet de classe E 
boolean remove(Object o) : enleve o s'il existe
boolean contains(Object o)
Iterator\<E> iterator() : retourne un iterateur sur le set

#### ArrayList

boolean add(E e) : ajouter en fin de liste
void add(int index, E e) :  insertion en index
E set(int index)
int indexOf(Object o);

##### HashMap

v put(k key, v value) : ajoute/modifie un ensemble (cle, valeur). Si la cle existe deja alors l'ancienne est écrasée et remplacée.
v get(Object key) : renvoie l'objet associé a la clé si elle existe
boolean containsKey(Object key)
v remove(Object key) : supprice et retourne la valeur associé a la clé
Set\<K> keySet() : renvoie un set des clés

#### ArrayQueue
**File**
boolean offer(E e) : ajoute en fin de queue
E poll() : supprime et renvoie l'element en tete de queue

**Pile**
void push(E e) : ajoute en debut de queue
E pop() : supprime et renvoie l'element en tete de queue
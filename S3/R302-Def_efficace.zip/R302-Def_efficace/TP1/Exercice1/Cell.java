public class Cell {
    public int value;
    public Cell next;

    public Cell(int value) {
        this.value = value;
        next = null;
    }
}
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>



int main()
{
    pid_t pid = fork();

    affiche_car(pid);

    return 0;
}

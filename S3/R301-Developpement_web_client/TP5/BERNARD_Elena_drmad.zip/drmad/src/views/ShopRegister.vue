<template>
    <div>
        <h1>Register</h1>
        <p>Enregistrez vous (TODO) ((maybe))</p>
    </div>
</template>
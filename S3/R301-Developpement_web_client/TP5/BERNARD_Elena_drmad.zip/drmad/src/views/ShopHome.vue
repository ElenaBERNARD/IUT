<template>
    <div>
        <h1>Home</h1>
        <p>Bienvenue à la boutique</p>
    </div>
</template>
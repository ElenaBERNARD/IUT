<template>
    <div>
        <h1>Home</h1>
        <p>Bienvenue à la banque</p>
    </div>
</template>
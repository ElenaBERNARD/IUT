package Morpion;

public class Coordonnee {

    public final int ligne;
    public final int colonne;

    public Coordonnee(int ligne, int colonne) {
        this.colonne = colonne;
        this.ligne = ligne;
    }
}

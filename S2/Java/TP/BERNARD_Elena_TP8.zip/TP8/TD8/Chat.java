public class Chat extends Animal {
    @Override
    public void crier() {
        System.out.println("Miaou");
    }
}

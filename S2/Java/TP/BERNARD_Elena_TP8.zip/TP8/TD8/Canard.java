public class Canard extends Animal {
    @Override
    public void crier(){
        System.out.println("Coin");
    }    
}

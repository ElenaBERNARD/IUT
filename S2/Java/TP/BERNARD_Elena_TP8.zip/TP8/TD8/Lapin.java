public class Lapin extends Animal {
    public void crier(){
        System.out.println("Carotte");
    }
}

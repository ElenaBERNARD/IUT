public class Serpent extends Animal {
    @Override
    public void crier(){
        System.out.println("Tss");
    }
}

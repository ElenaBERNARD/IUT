public class Animal {
    public void crier(){
        System.out.println("Graou");
    }
}
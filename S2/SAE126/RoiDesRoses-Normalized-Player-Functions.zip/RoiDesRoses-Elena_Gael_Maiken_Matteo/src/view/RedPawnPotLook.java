package view;

import boardifier.model.ContainerElement;
import boardifier.view.TableLook;

public class RedPawnPotLook extends TableLook {

    public RedPawnPotLook(ContainerElement containerElement) {
        super(containerElement, -1, 1);
    }

}
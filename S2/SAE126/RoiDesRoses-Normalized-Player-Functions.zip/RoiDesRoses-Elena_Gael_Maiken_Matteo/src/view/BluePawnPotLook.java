package view;

import boardifier.model.ContainerElement;
import boardifier.view.TableLook;

public class BluePawnPotLook extends TableLook {

    public BluePawnPotLook(ContainerElement containerElement) {
        super(containerElement, -1, 1);
    }
}